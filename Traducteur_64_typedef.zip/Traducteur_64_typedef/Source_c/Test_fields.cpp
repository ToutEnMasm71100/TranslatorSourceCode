#include <windows.h>
#include <commctrl.h>
#include <iostream>
#include <conio.h>


/* 
bool, char, char8_t, unsigned char, signed char, __int8	1 byte
char16_t, __int16, short, unsigned short, wchar_t, __wchar_t	2 bytes
char32_t, float, __int32, int, unsigned int, long, unsigned long	4 bytes
double, __int64, long double, long long, unsigned long long	8 bytes

*/

/*
champs de bits = bits de X a Y
contenant de champs = variable de 8,16,32,64 bits
Taille par defaut du contenant des champs,int ,4 bytes
Alignement par defaut int,8 bytes sinon sur taille contenant des champs
Taille minimum structure champs de bits ,2 bytes avec un champ de bit short ,1 byte
Taille du contenant des champs de bits acceptés:
------  bool, char, char8_t, unsigned char, signed char, __int8	1 byte
------  char16_t, __int16, short, unsigned short, wchar_t, __wchar_t	2 bytes
------  char32_t, float, __int32, int, unsigned int, long, unsigned long	4 bytes
------  double, __int64, long double, long long, unsigned long long	8 bytes
Declaration:
Les bits vont du poids faible au poids fort. premier:3,deux:4 donne premier:bit 0 a 2,deux bits 3 a 6
Creation de nouveau contenant de champs:
 Lorsque la Somme des bits précédents excede la taille defini du champ.
Alignement:
***** Peut etre provoque par un champ de bits NULL :0   size DWORD 32 bits
***** L'alignement s'effectue sur la taille du contenant ou le minimum accepté ,word
***** L'alignement byte n'etant pas accepté,on prend l'alignement par defaut int,4 bytes
***** C'est ce qui fait que la taille minimum d'une structure est obtenu avec un contenant de champ short,2 bytes
***** Un changement de valeur de contenant dans la structure provoque un realignement dont la taille 
	est celle du nouveau contenant
*/

/* english
bit fields = bits of X A Y
container for  fields = 4,8,16,32,64-bit
Default size of the containing fields,int,4 bytes
Alignment by default int,8 bytes otherwise on size containing fields
Minimum size structure bit fields ,1 byte
Container size of accepted bit fields:
------  bool, char, char8_t, unsigned char, signed char, __int8   1 byte
------  char16_t, __int16, short, unsigned short, wchar_t, __wchar_t   2 bytes
------  char32_t, float, __int32, int, unsigned int, long, unsigned long   4 bytes
------  double, __int64, long double, long long, unsigned long long   8 bytes
Declaration:
The bits range from low to high weight. "field1:3,field2:4" gives "field1:bit 0 a 2",field2 bits 3 a 6
Creating new fields containing:
 When the Sum of the preceding bits excess the defined size of the container or when a new size of container is used
alignment:
The alignment is done on the size of the bigger container or with a NULL bit field:0 (align DWORD)
A change in the size of the container  causes a realignement of the precedent bitfield 
at the size of the new container

*/




typedef /* [public][uuid] */  DECLSPEC_UUID("66504313-BE0F-101A-8BBB-00AA00300CAB") UINT OLE_HANDLE;

typedef /* [hidden][uuid] */  DECLSPEC_UUID("66504306-BE0F-101A-8BBB-00AA00300CAB") LONG OLE_XPOS_HIMETRIC;

typedef /* [hidden][uuid] */  DECLSPEC_UUID("66504307-BE0F-101A-8BBB-00AA00300CAB") LONG OLE_YPOS_HIMETRIC;

typedef /* [hidden][uuid] */  DECLSPEC_UUID("66504308-BE0F-101A-8BBB-00AA00300CAB") LONG OLE_XSIZE_HIMETRIC;

typedef /* [hidden][uuid] */  DECLSPEC_UUID("66504309-BE0F-101A-8BBB-00AA00300CAB") LONG OLE_YSIZE_HIMETRIC;

typedef  struct _st
  {
     unsigned long long champ_1: 1,
     champ_2: 1,
     champ_3: 1,
     champ_4: 1,
     champ_5: 1;
  }st;

struct dDate {                   // taille ?
   unsigned short nWeekDay : 3; // 0à1: (3 bits)
   unsigned short nMonthDay : 6; // 2: (6 bits)
   unsigned  nMonth : 5;     // 4à7: (5 bits)
   unsigned short nYear     : 8; // 8: (8 bits)
                                // alignement:9à11
};


typedef struct _SES_ENCLOSURE_DESCRIPTOR {
    UCHAR NumberOfEnclosureServices : 3;        // Byte  0, bit 0-2
    UCHAR Reserved1 : 1;                        // Byte  0, bit 3
    UCHAR RelativeEnclosureServicesId : 3;      // Byte  0, bit 4-6
    UCHAR Reserved2 : 1;                        // Byte  0, bit 7
    UCHAR SubEnclosureId;                       // Byte  1
    UCHAR NumberOfTypeDescriptorHeaders;        // Byte  2
    UCHAR EnclosureDescriptorLength;            // Byte  3
    UCHAR Identifier[8];                        // Byte  4-11
    UCHAR VendorId[8];                          // Byte 12-19
    UCHAR ProductId[16];                        // Byte 20-35
    UCHAR ProductRevisionLevel[4];              // Byte 36-39
    UCHAR VendorSpecific[ANYSIZE_ARRAY];

} SES_ENCLOSURE_DESCRIPTOR, *PSES_ENCLOSURE_DESCRIPTOR;
typedef struct _NDIS_TCP_IP_CHECKSUM_PACKET_INFO
{
    union
    {
        struct
        {
            ULONG   NdisPacketChecksumV4:1;
            ULONG   NdisPacketChecksumV6:1;
            ULONG   NdisPacketTcpChecksum:1;
            ULONG   NdisPacketUdpChecksum:1;
            ULONG   NdisPacketIpChecksum:1;
        } Transmit;

        struct
        {
            ULONG   NdisPacketTcpChecksumFailed:1;
            ULONG   NdisPacketUdpChecksumFailed:1;
            ULONG   NdisPacketIpChecksumFailed:1;
            ULONG   NdisPacketTcpChecksumSucceeded:1;
            ULONG   NdisPacketUdpChecksumSucceeded:1;
            ULONG   NdisPacketIpChecksumSucceeded:1;
            ULONG   NdisPacketLoopback:1;
        } Receive;

        ULONG   Value;
    };
} NDIS_TCP_IP_CHECKSUM_PACKET_INFO, *PNDIS_TCP_IP_CHECKSUM_PACKET_INFO;


  struct ACLOSE_TRACK {          // taille 10 au lieu de 13
       // UCHAR OperationCode;    // 0x5B - SCSIOP_CLOSE_TRACK_SESSION
        UCHAR Immediate : 1;
        UCHAR Reserved1 : 2;
        UCHAR Track     : 3;
        UCHAR Session   : 4;
        UCHAR Reserved2 : 2;
       // UCHAR Reserved3;
       // UCHAR TrackNumber[2];
       // UCHAR Reserved4[3];
       // UCHAR Control;
    };

struct Date {           //taile 4
   unsigned short nWeekDay  : 1;    
   unsigned short nMonthDay : 1;   
   unsigned short nMonth    : 1;    
   unsigned short nYear     : 1;    
   unsigned short lunaire    : 1;    
   unsigned short martien    : 1;    
   unsigned short saturnien    : 1;    
};


struct DateAlign {     //8
   unsigned nWeekDay  : 3;    // 0..7   (3 bits)
   unsigned nMonthDay : 6;    // 0..31  (6 bits)
   unsigned           : 0;    // Force alignment to next boundary.
   unsigned nMonth    : 5;    // 0..12  (5 bits)
   unsigned nYear     : 8;    // 0..100 (8 bits)
};

struct MiniMum {
    short nWeekDay  : 2;    // 0..7   (3 bits)
    short WeekDay  : 2;    // 0..7   (3 bits)
    unsigned  : 0;
    short aWeekDay  : 7;
    short BWeekDay  : 7;
    short CWeekDay  : 7;
    short DWeekDay  : 7;
    short FWeekDay  : 7;
   //unsigned nMonthDay : 1;    // 0..31  (6 bits)
};





int main()
{	int total=0;
	MiniMum autre;
	/*
	// 28 a 12 avec struct in6_addr sin6_addr
	printf("  machin.OperationCode : %d \n",sizeof(machin.OperationCode));
	total= total + sizeof(machin.OperationCode);
	printf(" sizeof  machin.Immediate .. Not allowed \n");
//	printf("  machin.Reserved1 : %d \n",sizeof(machin.Reserved1));
//	printf("  machin.Track  : %d \n",sizeof(machin.Track ));		
//	printf("  machin.Session : %d \n",sizeof(machin.Session));
//	printf("  machin.Reserved2 : %d \n",sizeof(machin.Reserved2));	
	printf("  machin.Reserved3 : %d \n",sizeof(machin.Reserved3));	
	total= total + sizeof(machin.Reserved3);		
	printf("  machin.TrackNumber[2] : %d \n",sizeof(machin.TrackNumber));
	total= total + sizeof(machin.TrackNumber);
	printf("  machin.Reserved4[3] : %d \n",sizeof(machin.Reserved4));	
	total= total + sizeof(machin.Reserved4);
	printf("  machin.Control : %d \n",sizeof(machin.Control));				
	total= total + sizeof(machin.Control);
	printf(" ------ Total ------- : %d \n",total);
	//------------------------------------------------------------	
	*/
	printf(" taille autre : %d \n",sizeof(autre));
	//printf(" taille ruse : %d \n",sizeof(ruse));		
	_getch();
    return 0;
}
